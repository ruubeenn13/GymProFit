package com.gymprofit.api.repository.jpa;

import com.gymprofit.api.entity.Comida;
import io.swagger.v3.oas.annotations.Hidden;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Hidden
@Repository
public interface IComidaRepository extends CrudRepository<Comida, Integer> {
}
